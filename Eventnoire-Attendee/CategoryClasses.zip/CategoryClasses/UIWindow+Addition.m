//
//  UIWindow+Addition.m
//  Coachify
//
//  Created by Raj Kumar Sharma on 17/11/16.
//  Copyright © 2016 Mobiloitte. All rights reserved.
//

#import "UIWindow+Addition.h"
#import "JASidePanelController.h"

@implementation UIWindow (Addition)

- (UIViewController *)currentController {
    
    if ([[self topViewControllerWithRootViewController:[UIApplication sharedApplication].keyWindow.rootViewController] isKindOfClass:[JASidePanelController class]]) {
        
        JASidePanelController *slidePanel = (JASidePanelController *)[self topViewControllerWithRootViewController:[UIApplication sharedApplication].keyWindow.rootViewController];
        
        return [self topViewControllerWithRootViewController:slidePanel.centerPanel];
        
    } else {
        return [self topViewControllerWithRootViewController:[UIApplication sharedApplication].keyWindow.rootViewController];
    }
}

- (UIViewController *)topViewControllerWithRootViewController:(UIViewController*)rootViewController {
    
    if ([rootViewController isKindOfClass:[UITabBarController class]]) {
        UITabBarController* tabBarController = (UITabBarController*)rootViewController;
        return [self topViewControllerWithRootViewController:tabBarController.selectedViewController];
    } else if ([rootViewController isKindOfClass:[UINavigationController class]]) {
        UINavigationController* navigationController = (UINavigationController*)rootViewController;
        return [self topViewControllerWithRootViewController:navigationController.visibleViewController];
    } else if (rootViewController.presentedViewController) {
        UIViewController* presentedViewController = rootViewController.presentedViewController;
        return [self topViewControllerWithRootViewController:presentedViewController];
    } else {
        return rootViewController;
    }
}

@end
