//
//  UIWindow+Addition.h
//  Coachify
//
//  Created by Raj Kumar Sharma on 17/11/16.
//  Copyright © 2016 Mobiloitte. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIWindow (Addition)

- (UIViewController *)currentController;

@end
