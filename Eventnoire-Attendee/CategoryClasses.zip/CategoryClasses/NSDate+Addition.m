//
//  NSDate+Addition.m
//  VoiceSociety
//
//  Created by Raj Kumar Sharma on 06/08/16.
//  Copyright © 2016 Mobiloitte. All rights reserved.
//

#import "NSDate+Addition.h"

@implementation NSDate (Addition)

- (NSString *)UTCDateFormat {
    
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
   // [dateFormat setDateFormat:@"yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'SSSZ"];
    [dateFormat setDateFormat:@"yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'SSS'Z'"];

    return [dateFormat stringFromDate:self];
}

- (NSTimeInterval)convertDateToTimeStamp {
    
    NSTimeInterval seconds = [self timeIntervalSince1970];
    double milliseconds = seconds*1000;
    
    return milliseconds;
}

- (NSString *)getDateString {
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setTimeZone:[NSTimeZone systemTimeZone]]; // new line added
    
    [dateFormatter setDateFormat:@"MMM d, yyyy"];
    
    return [dateFormatter stringFromDate:self];
}

- (NSString *)getDateTimeString {
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setTimeZone:[NSTimeZone systemTimeZone]]; // new line added

    [dateFormatter setDateFormat: @"MMM d, yyyy, hh:mm a"];
    
    return [dateFormatter stringFromDate:self];
}

- (NSString *)getTimeDateString {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setTimeZone:[NSTimeZone systemTimeZone]]; // new line added

    [dateFormatter setDateFormat: @"hh:mm a, MMM d, yyyy"];
    
    return [dateFormatter stringFromDate:self];
}

- (NSString *)getDateStringWithFormat:(NSString *)format {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:format];
    
    return [dateFormatter stringFromDate:self];
}

- (NSString *)getTimeString {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
   // [dateFormatter setLocale:[self enUSPosixlocal]];
    [dateFormatter setTimeZone:[NSTimeZone systemTimeZone]]; // new line added

    [dateFormatter setDateFormat:@"hh:mm a"];
    
    return [dateFormatter stringFromDate:self];
}

- (NSLocale *)enUSPosixlocal {
    return  [[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"];
}

@end
