//
//  UIButton+Addition.h
//  VoiceSociety
//
//  Created by Raj Kumar Sharma on 20/09/16.
//  Copyright © 2016 Mobiloitte. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (Addition)

- (void)disable:(BOOL)status;

@end
